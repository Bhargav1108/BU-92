/* These Functions are for showing popup Windows */

function openForm() {
  document.getElementById("myForm").style.display = "flex";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}

function orderOpen(){
  document.getElementById("avi").style.display = "flex";
}

function orderClose(){
 document.getElementById("avi").style.display = "none";
}

function orderO(){
  document.getElementById("openO").style.display = "flex";
}

function orderC(){
 document.getElementById("openO").style.display = "none";
}
function oO1(){
  document.getElementById("o1").style.display = "flex";
}

function oC1(){
 document.getElementById("o1").style.display = "none";
}

function oO2(){
  document.getElementById("o2").style.display = "flex";
}

function oC2(){
 document.getElementById("o2").style.display = "none";
}

function oO3(){
  document.getElementById("o3").style.display = "flex";
}

function oC3(){
 document.getElementById("o3").style.display = "none";
}

function oO4(){
  document.getElementById("o4").style.display = "flex";
}

function oC4(){
 document.getElementById("o4").style.display = "none";
}


function trainB(){
  document.getElementById("bookTrain").style.display = "flex";
}

function trainC(){
  document.getElementById("bookTrain").style.display = "none";
}
